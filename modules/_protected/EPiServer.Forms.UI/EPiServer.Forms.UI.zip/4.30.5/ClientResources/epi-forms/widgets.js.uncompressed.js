/* Dummy file to trick the AMD loader when running debug mode
*  the application will lookup required modules at this file first, and if this file is empty, 
*  browser will load real forms ui js modules.
*/
