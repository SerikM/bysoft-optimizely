define("epi-forms/widget/FormsContentTypeList", [// dojo
"dojo/_base/array", "dojo/_base/declare", "dojo/_base/lang", "dojo/when", // dijit
"dijit/layout/_LayoutWidget", // epi
"epi/dependency", "epi/shell/TypeDescriptorManager", // epi-addons
"epi-forms/ModuleSettings", "epi-forms/widget/FormsContentTypeGroup"], function ( // dojo
array, declare, lang, when, // dijit
_LayoutWidget, // epi
dependency, TypeDescriptorManager, // epi-addons
ModuleSettings, FormsContentTypeGroup) {
  // module:
  //      epi-forms/widget/FormsContentTypeList
  // summary:
  //      A list of suggested and available content types for content creation.
  //      Displays a list of suggested and available content types for content creation.
  // tags:
  //      public
  return declare([_LayoutWidget], {
    // store: [readonly] dojo.store
    //      Underlying store which will be queried for data to display.
    store: null,
    // _defaultDataStoreName: [protected] String
    //		Default data store name to get from registry, if store is null.
    _defaultDataStoreName: "epi.cms.content.light",
    // parentLink: [public] String
    //      Link to parent content which the new content will be created beneath.
    parentLink: null,
    // groups: [public] Object
    //      Named value object containing the current content type groups.
    groups: null,
    // requestedType: [public] String
    //      Specify the content type to be shown on the list.
    requestedType: null,
    // allowedTypes: [public] Array
    //      The types which are allowed. i.e used for filtering based on AllowedTypesAttribute
    allowedTypes: null,
    // restrictedTypes: [public] Array
    //      The types which are restricted.
    restrictedTypes: null,
    contentTypeService: null,
    _setLocalAssetAttr: function _setLocalAssetAttr(localAsset) {
      this._set("localAsset", localAsset);

      if (this.requestedType && this.parentLink) {
        this.refresh();
      }
    },
    _setParentLinkAttr: function _setParentLinkAttr(value) {
      this._set("parentLink", value);

      if (this.requestedType) {
        this.refresh();
      }
    },
    postMixInProperties: function postMixInProperties() {
      // summary:
      //      Initiates the store if none has been mixed in.
      // tags:
      //      protected
      this.inherited(arguments);
      this.groups = {};
      this.contentTypeService = this.contentTypeService || dependency.resolve("epi.cms.ContentTypeService");

      if (!this.store) {
        var registry = dependency.resolve("epi.storeregistry");
        this.store = registry.get(this._defaultDataStoreName);
      }
    },
    refresh: function refresh() {
      // summary:
      //      Refresh the content and rendered view of the list.
      // tags:
      //      public
      // Clear any existing data first to stop flickering in the UI.
      this.clear();

      this._setupWidgetTemplate();

      this._getChildren(lang.hitch(this, function (children) {
        var grouped = {};
        array.forEach(children, function (item) {
          var groupName = item.groupName || this._otherTypesTitle;

          if (!grouped[groupName]) {
            grouped[groupName] = [];
          }

          grouped[groupName].push(item);
        }); // Clear and load the available content types sorted into groups.

        var key, group; // Update remaining groups with new content types.

        for (key in grouped) {
          group = this._getOrCreateGroup(key);
          group.set("contentTypes", grouped[key]);
        }
      }));
    },
    setVisibility: function setVisibility(display) {
      // summary:
      //      The common method to show / hide this widget
      // display: [Boolean]
      //      The flag to show or hide.
      // tags:
      //      pubic
      this.getChildren().forEach(function (group) {
        group.setVisibility(display);
      }, this);
    },
    _setupWidgetTemplate: function _setupWidgetTemplate() {
      this._otherTypesTitle = TypeDescriptorManager.getResourceValue(this.requestedType, "othertypes");
    },
    clear: function clear() {
      // summary:
      //      Removes all the content types groups from the current view, except for
      //      suggested content types which will only have it's children removed.
      // tags:
      //      public
      for (var key in this.groups) {
        this.groups[key].destroyRecursive();
        delete this.groups[key];
      }
    },
    _getOrCreateGroup: function _getOrCreateGroup(name) {
      var group = this.groups[name];

      if (!group) {
        group = new FormsContentTypeGroup({
          title: name
        });
        this.addChild(group);
        this.groups[name] = group;
      }

      return group;
    },
    _getChildren: function _getChildren(onComplete) {
      // summary:
      //      Group the available content types.
      // tags:
      //      private
      if (!(this.allowedTypes instanceof Array)) {
        this.allowedTypes = [];
      }

      var formElementContentTypes = ModuleSettings.formElementContentTypes;

      if (formElementContentTypes instanceof Array && formElementContentTypes.length > 0) {
        this.allowedTypes.push.apply(this.allowedTypes, formElementContentTypes);
      }

      var results = this.contentTypeService.getAcceptedChildTypes(this.parentLink, this.localAsset, [this.requestedType], this.allowedTypes, this.restrictedTypes);
      when(results, onComplete);
    }
  });
});